//
//  ProductInfoViewController.swift
//  MindfulBeauty
//
//  Created by Ritu K on 4/18/19.
//  Copyright © 2019 Ritu K. All rights reserved.
//

import Foundation
import UIKit

class ProductInfoViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        if let name = ProductData.defaults.string(forKey: "product name") {
            productName.text = name
            
            if name == "Old Spice Red Zone Collection Swagger Scent Deodorant 3 Oz" {
                productImage.image = UIImage(named: "OldSpice")
                crueltyFree.text = "This company is not cruelty free."
                harmfulIng.text = "Potentially harmful ingredients:\n Propylene Glycol (medium hazard)\n Tetrasodium EDTA (low hazard)"
                allergens.text = "Possible allergens:\n Fragrance"
            }
            
            if name == "Dove Advanced Care Antiperspirant ClearTone Skin Renew 2.6 Oz" {
                productImage.image = UIImage(named: "Dove")
                crueltyFree.text = "This company is cruelty free!"
                harmfulIng.text = "Potentially harmful ingredients:\n Guar Gum (Low hazard)"
                allergens.text = "No potential allergens."
            }
            
            if name == "Revlon PhotoReady Makeup, Vanilla, 1-Fluid Ounce" {
                productImage.image = UIImage(named: "Revlon")
                crueltyFree.text = "This company is not cruelty free."
                harmfulIng.text = "Potentially harmful ingredients:\n Phenoxyethanol (Medium Hazard)\n Cyclopentasiloxane (low hazard)\n Boron Nitride (Low Hazard)\n Aluminum Oxide (Low Hazard)\n Sorbitan Sesquioleate (Low Hazard)\n Tetrasodium EDTA (Low Hazard)\n Titanium Dioxide (Low Hazard)\n Zinc Oxide (Low Hazard)"
                allergens.text = "No potential allergens."
            }
            
            if name == "Shea Moisture - Raw Shea Butter Moisture Retention Shampoo - 13 Fl. Oz." {
                productImage.image = UIImage(named: "SheaMoisture")
                crueltyFree.text = "This company is cruelty free!"
                harmfulIng.text = "Guar Gum (Low hazard)"
                allergens.text = "Possible allergens:\n Fragrance"
            }
        }
    }
    
    @IBOutlet weak var productName: UILabel!
    
    @IBOutlet weak var productImage: UIImageView!
    
    @IBOutlet weak var crueltyFree: UILabel!
    
    @IBOutlet weak var harmfulIng: UILabel!
    
    @IBOutlet weak var allergens: UILabel!
    
    
}
