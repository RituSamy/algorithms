//
//  ProductData.swift
//  MindfulBeauty
//
//  Created by Ritu K on 4/18/19.
//  Copyright © 2019 Ritu K. All rights reserved.
//

import Foundation
import UIKit

class ProductData {
    static let defaults = UserDefaults()
}
